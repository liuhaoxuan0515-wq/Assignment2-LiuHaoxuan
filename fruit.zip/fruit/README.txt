普通水果照片：苹果、香蕉、橙子、草莓；有桌面、果堆、植物等真实背景。
每类30张，train 21 / val 6 / test 3，共120张，7:2:1。
来源：RawRipe 公开照片库 https://github.com/ai-agriculture-circuits-and-systems/RawRipe
照片仍来自公开数据集，但不使用先前白底旋转水果图片。来源见sources.csv，许可见LICENSE.txt。
部分图片含多个同类水果，可用于整张图片分类。
